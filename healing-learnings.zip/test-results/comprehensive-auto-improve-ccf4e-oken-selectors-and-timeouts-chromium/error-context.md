# Page snapshot

```yaml
- generic [ref=e1]:
  - heading "AI-SDLC Demo Page" [level=1] [ref=e2]
  - button "Primary Action" [ref=e3]
  - button "Credit Score" [ref=e4]
  - button "Submit Credit Application" [ref=e5]
  - generic [ref=e6]: "720"
  - generic [ref=e8]: Application submitted
  - textbox [ref=e9]: "***-**-6789"
  - textbox [active] [ref=e10]: Need credit repair services
  - button "Choose File" [ref=e11]
  - button "Dispute" [ref=e12]
  - combobox [ref=e13]
  - button "Submit Dispute" [ref=e14]
  - generic [ref=e15]: Dispute submitted successfully
```
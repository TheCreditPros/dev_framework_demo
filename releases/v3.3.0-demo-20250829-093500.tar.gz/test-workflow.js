// Test file to validate AI-SDLC workflow
const testFunction = (name) => {
  console.log(`Hello, ${name}!`);
  return true;
};

module.exports = testFunction;
